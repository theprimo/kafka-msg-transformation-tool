/*
 * a source connector receives records from an upstream system, converts it to a ConnectRecord, and then passes that 
 * record through the apply() function of the transformation(s) that have been configured, expecting a record back. 
 * The same process happens for a sink connector, but in reverse. After reading and deserializing each message from 
 * the source Kafka topic, the apply() function of the transformation(s) is called, and the resulting record is sent 
 * to the target system.
 * 
 * https://www.confluent.io/blog/kafka-connect-single-message-transformation-tutorial-with-examples
 *
 */

package org.apache.kafka.connect.transforms;

import static org.apache.kafka.connect.transforms.util.Requirements.requireMap;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.connect.connector.ConnectRecord;
import org.apache.kafka.connect.data.Schema;
	

public abstract class CustomTransform<R extends ConnectRecord<R>> implements Transformation<R> {

	public static final String OVERVIEW_DOC =
			"Make the changes below to each recieved record from source connector and pass it further"
					+ "group doc type_ - group to Group "
					+ "transactionDetail doc type_ - transactionDetail to TransactionDetail"
					+ "customer doc - addressDetails.address.countryCode to MY ";


	private static final String PURPOSE = "custom transformations";

	@SuppressWarnings("unused")
	private String fieldNames;

	@Override
	public R apply(R record) {
		//only we're dealing with schemaless records
		if (operatingValue(record) == null || operatingSchema(record) != null) {
			return record;
		}
		return applySchemaless(record);
	}

	protected abstract Schema operatingSchema(R record);

	protected abstract Object operatingValue(R record);

	protected abstract R newRecord(R record, Schema updatedSchema, Object updatedValue);

	@SuppressWarnings("unchecked")
	private R applySchemaless(R record) {
		final Map<String, Object> value = requireMap(operatingValue(record), PURPOSE);
		final LinkedHashMap<String, Object> updatedValue = new LinkedHashMap<>(value);

		//update type_ -- group -> Group, transactionDetail -> TransactionDetail
		if(value.containsKey("type_")) {
			String key="type_";
			String val = (value.get(key)).toString();
			if(val.equals("group")) {
				updatedValue.put(key, "Group");
			}else if(val.equals("transactionDetail")) {
				updatedValue.put(key, "TransactionDetail");
			}            		
		}    

		//update customer -- addressDetails.address.countryCode to MY		
		if(value.containsKey("type_")) {			
			String val = (value.get("type_")).toString();
			if(val.equals("customer")) {
				Map<String, Object> addressDetails,address;				
				if(value.containsKey("addressDetails")) {
					addressDetails=(LinkedHashMap<String, Object>)value.get("addressDetails");
					address=(LinkedHashMap<String, Object>)addressDetails.get("address");
				}else {
					addressDetails = new LinkedHashMap<String, Object> ();
					address = new LinkedHashMap<String, Object> ();					
				}
				address.put("countryCode", "MY");					
				addressDetails.put("address", address);
				updatedValue.put("addressDetails", (Object)addressDetails);
			}			
		}
		return newRecord(record, null, updatedValue);
	}

	@Override
	public void close() {
	}

	@Override
	public ConfigDef config() {
		return new ConfigDef();
	}

	@Override
	public void configure(Map<String, ?> configs) {
	}

	public static class Key<R extends ConnectRecord<R>> extends CustomTransform<R> {
		@Override
		protected Schema operatingSchema(R record) {
			return record.keySchema();
		}

		@Override
		protected Object operatingValue(R record) {
			return record.key();
		}

		@Override
		protected R newRecord(R record, Schema updatedSchema, Object updatedValue) {
			return record.newRecord(record.topic(), record.kafkaPartition(), updatedSchema, updatedValue, record.valueSchema(), record.value(), record.timestamp());
		}
	}

	public static class Value<R extends ConnectRecord<R>> extends CustomTransform<R> {
		@Override
		protected Schema operatingSchema(R record) {
			return record.valueSchema();
		}

		@Override
		protected Object operatingValue(R record) {
			return record.value();
		}

		@Override
		protected R newRecord(R record, Schema updatedSchema, Object updatedValue) {
			return record.newRecord(record.topic(), record.kafkaPartition(), record.keySchema(), record.key(), updatedSchema, updatedValue, record.timestamp());
		}
	}
}


